import { veriGetir } from './db.js';
import { ogrenciGosteriminiBaslat } from '../modules/ogrenciler/gosterim.js';
import { duyuruGosteriminiBaslat } from '../modules/duyurular/gosterim.js';

document.addEventListener('DOMContentLoaded', () => {
    // 1. Modülleri Başlat
    ogrenciGosteriminiBaslat('gosterim-sahnesi');
    duyuruGosteriminiBaslat('gosterim-sahnesi');

    // 2. Sandviç Menü (Sidebar) İşlemleri
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    const hamburgerBtn = document.getElementById('hamburger-btn');
    const closeBtn = document.getElementById('close-btn');
    const fullscreenBtn = document.getElementById('fullscreen-btn');
    const sidebarFullscreenBtn = document.getElementById('sidebar-fullscreen-btn');

    function toggleFullscreen() {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => {
                alert(`Hata: Tam ekran yapılamadı. (${err.message})`);
            });
        } else {
            document.exitFullscreen();
        }
    }

    // Menüyü Açma Fonksiyonu
    function menuyuAc() {
        sidebar.classList.add('acik');
        overlay.classList.add('acik');
    }

    // Menüyü Kapatma Fonksiyonu
    function menuyuKapat() {
        sidebar.classList.remove('acik');
        overlay.classList.remove('acik');
    }

    // Buton Dinleyicileri
    hamburgerBtn.addEventListener('click', menuyuAc);
    closeBtn.addEventListener('click', menuyuKapat);
    overlay.addEventListener('click', menuyuKapat); // Boşluğa tıklayınca da kapansın

    // Tam Ekran Yapma Butonu İşlevi
    fullscreenBtn.addEventListener('click', (e) => {
        e.preventDefault();
        toggleFullscreen();
    });

    if (sidebarFullscreenBtn) {
        sidebarFullscreenBtn.addEventListener('click', (e) => {
            e.preventDefault();
            toggleFullscreen();
            menuyuKapat();
        });
    }
});
