export function veriKaydet(anahtar, veri) {
    localStorage.setItem(anahtar, JSON.stringify(veri));
    window.dispatchEvent(new Event('veriGuncellendi'));
}

export function veriGetir(anahtar) {
    const veri = localStorage.getItem(anahtar);
    return veri ? JSON.parse(veri) : null;
}

window.addEventListener('storage', () => {
    window.dispatchEvent(new Event('veriGuncellendi'));
});