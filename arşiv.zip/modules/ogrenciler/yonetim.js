import { veriKaydet, veriGetir } from '../../core/db.js';

export function ogrenciYonetiminiBaslat(hedefAlanId) {
    const sahne = document.getElementById(hedefAlanId);

    let modulAcikMi = veriGetir('ayar_ogrenci_modulu');
    if (modulAcikMi === null) modulAcikMi = true;

    sahne.insertAdjacentHTML('beforeend', `
        <div class="yonetim-kutusu">
            <div class="yonetim-kutu-baslik">
                <h3>👩‍🏫 Öğrenciler Modülü</h3>
                <button id="ogrenci-salter-btn" class="toggle-btn ${modulAcikMi ? 'toggle-btn--on' : 'toggle-btn--off'}">
                    ${modulAcikMi ? '👁️ Tahtada Açık' : '🚫 Tahtada Gizli'}
                </button>
            </div>

            <div class="form-alani">
                <input type="number" id="ogr-no" placeholder="Okul No" class="input-field">
                <input type="text" id="ogr-ad" placeholder="Ad Soyad" class="input-field">
                <button id="ogr-kaydet" class="button-primary">Sisteme Ekle</button>
            </div>
            <ul id="yonetim-ogrenci-listesi" class="yonetim-liste"></ul>
        </div>
    `);

    const btnEkle = document.getElementById('ogr-kaydet');
    const inputNo = document.getElementById('ogr-no');
    const inputAd = document.getElementById('ogr-ad');
    const liste = document.getElementById('yonetim-ogrenci-listesi');
    const salterBtn = document.getElementById('ogrenci-salter-btn');

    // Modülü Komple Aç/Kapat Butonu
    salterBtn.addEventListener('click', () => {
        modulAcikMi = !modulAcikMi; 
        veriKaydet('ayar_ogrenci_modulu', modulAcikMi);
        
        salterBtn.classList.toggle('toggle-btn--on', modulAcikMi);
        salterBtn.classList.toggle('toggle-btn--off', !modulAcikMi);
        salterBtn.innerText = modulAcikMi ? '👁️ Tahtada Açık' : '🚫 Tahtada Gizli';
    });

    function listeyiGuncelle() {
        const ogrenciler = veriGetir('ogrenciler') || [];
        liste.innerHTML = ogrenciler.map((ogr, index) => `
            <li class="yonetim-liste-eleman">
                <span><strong>${ogr.no}</strong> - ${ogr.ad}</span>
                <button class="sil-btn" data-index="${index}">Sil</button>
            </li>
        `).join('');
    }

    listeyiGuncelle();

    btnEkle.addEventListener('click', () => {
        const no = inputNo.value.trim();
        const ad = inputAd.value.trim();

        if (no !== "" && ad !== "") {
            let ogrenciler = veriGetir('ogrenciler') || [];
            ogrenciler.push({ no, ad });
            veriKaydet('ogrenciler', ogrenciler);
            
            inputNo.value = "";
            inputAd.value = "";
            inputNo.focus();
            listeyiGuncelle();
        }
    });

    liste.addEventListener('click', (e) => {
        if (e.target.classList.contains('sil-btn')) {
            const index = e.target.getAttribute('data-index');
            let ogrenciler = veriGetir('ogrenciler') || [];
            if(confirm('Silmek istediğinize emin misiniz?')) {
                ogrenciler.splice(index, 1);
                veriKaydet('ogrenciler', ogrenciler);
                listeyiGuncelle();
            }
        }
    });
}