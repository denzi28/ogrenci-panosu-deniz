import { ogrenciYonetiminiBaslat } from '../modules/ogrenciler/yonetim.js';
import { duyuruYonetiminiBaslat } from '../modules/duyurular/yonetim.js';

document.addEventListener('DOMContentLoaded', () => {
    const sifreEkrani = document.getElementById('sifre-ekrani');
    const yonetimPaneli = document.getElementById('yonetim-paneli');
    const girisBtn = document.getElementById('giris-btn');
    const sifreInput = document.getElementById('sifre-input');
    const hataMesaji = document.getElementById('hata-mesaji');

    girisBtn.addEventListener('click', () => {
        if (sifreInput.value === "1234") {
            // Şifre ekranını gizle, paneli göster (CSS çakışmasını engellemek için doğrudan flex veriyoruz)
            sifreEkrani.style.display = 'none';
            yonetimPaneli.style.display = 'flex'; 
            hataMesaji.style.display = 'none';
            
            // Modülleri kendi özel hedef alanlarında (div) başlat
            ogrenciYonetiminiBaslat('modul-ogrenci');
            duyuruYonetiminiBaslat('modul-duyuru');
        } else {
            hataMesaji.style.display = "block";
        }
    });

    // --- Menü Sekme (Tab) Tıklama Mantığı ---
    const menuButonlari = document.querySelectorAll('.menu-btn');
    const moduller = document.querySelectorAll('.modul-sahnesi');

    menuButonlari.forEach(btn => {
        btn.addEventListener('click', (e) => {
            // Aktif menü butonunun stilini değiştir
            menuButonlari.forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');

            // Tüm modülleri ekrandan gizle
            moduller.forEach(modul => {
                modul.style.display = 'none';
            });

            // Tıklanan butona ait hedef modülü ekranda göster
            const targetId = e.target.getAttribute('data-target');
            document.getElementById(targetId).style.display = 'block';
        });
    });

    // --- Mobil İçin Sandviç (Hamburger) Menü Mantığı ---
    const hamburgerBtn = document.getElementById('yonetim-hamburger');
    const sidebarListe = document.getElementById('sidebar-liste');
    
    if(hamburgerBtn) {
        hamburgerBtn.addEventListener('click', () => {
            sidebarListe.classList.toggle('acik');
        });
    }
});