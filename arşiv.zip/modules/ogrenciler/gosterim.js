import { veriGetir } from '../../core/db.js';

export function ogrenciGosteriminiBaslat(hedefAlanId) {
    const sahne = document.getElementById(hedefAlanId);

    sahne.insertAdjacentHTML('beforeend', `
        <div class="gosterim-kutusu" id="ogrenci-gosterim-alani">
            <h3>Sınıf Listesi</h3>
            <div id="ogrenci-vitrini" class="vitrin-grid"></div>
        </div>
    `);

    function listeyiCiz() {
        const anaKutu = document.getElementById('ogrenci-gosterim-alani');
        const vitrin = document.getElementById('ogrenci-vitrini');
        
        // Şalter durumunu kontrol et
        let modulAcikMi = veriGetir('ayar_ogrenci_modulu');
        if (modulAcikMi === null) modulAcikMi = true;

        if (!modulAcikMi) {
            anaKutu.style.display = 'none';
            return;
        } else {
            anaKutu.style.display = 'block';
        }

        const ogrenciler = veriGetir('ogrenciler') || [];
        if (ogrenciler.length === 0) {
            vitrin.innerHTML = "<p>Henüz öğrenci eklenmedi.</p>";
            return;
        }

        vitrin.innerHTML = ogrenciler.map(ogr => `
            <div class="ogrenci-karti">
                <span class="kart-no">${ogr.no}</span>
                <span class="kart-ad">${ogr.ad}</span>
            </div>
        `).join('');
    }

    listeyiCiz();
    window.addEventListener('veriGuncellendi', listeyiCiz);
}