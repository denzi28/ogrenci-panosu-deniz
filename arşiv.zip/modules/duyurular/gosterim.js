import { veriGetir } from '../../core/db.js';

export function duyuruGosteriminiBaslat(hedefAlanId) {
    const sahne = document.getElementById(hedefAlanId);

    sahne.insertAdjacentHTML('beforeend', `
        <div class="gosterim-kutusu" id="duyuru-gosterim-alani">
            <h3>📌 Güncel Duyurular</h3>
            <ul id="duyuru-vitrini" class="vitrin-liste"></ul>
        </div>
    `);

    function duyurulariCiz() {
        const anaKutu = document.getElementById('duyuru-gosterim-alani');
        const vitrin = document.getElementById('duyuru-vitrini');
        
        // Şalter durumunu kontrol et
        let modulAcikMi = veriGetir('ayar_duyuru_modulu');
        if (modulAcikMi === null) modulAcikMi = true;

        // Şalter kapalıysa tüm modülü gizle ve işlemi durdur
        if (!modulAcikMi) {
            anaKutu.style.display = 'none';
            return;
        } else {
            anaKutu.style.display = 'block';
        }

        // Şalter açıksa verileri çiz
        const duyurular = veriGetir('duyurular') || [];
        if (duyurular.length === 0) {
            vitrin.innerHTML = "<p>Şu an için yeni bir duyuru yok.</p>";
            return;
        }

        vitrin.innerHTML = duyurular.map(duyuru => `
            <li class="duyuru-maddesi">✨ ${duyuru}</li>
        `).join('');
    }

    duyurulariCiz();
    window.addEventListener('veriGuncellendi', duyurulariCiz);
}